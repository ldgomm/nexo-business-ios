//
//  BusinessAccountantPackSurfaceView.swift
//  Nexo Business
//
//  21I.16B — Minimal accountant pack surface
//

import Combine
import Foundation
import SwiftUI

struct BusinessAccountantPackBottomBar: View {
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: "doc.zipper")
                    .font(.headline)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Paquete contador")
                        .font(.subheadline.weight(.semibold))
                    Text("Descarga mensual precontable")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.up")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(.thinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .padding(.horizontal, 18)
            .padding(.bottom, 6)
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("business.accountantPack.bottomBar")
    }
}

struct BusinessAccountantPackMoreTile: View {
    let container: BusinessAppContainer

    var body: some View {
        NavigationLink {
            BusinessAccountantPackSurfaceView(container: container)
        } label: {
            HStack(alignment: .center, spacing: 14) {
                Image(systemName: "doc.zipper")
                    .font(.title3.weight(.semibold))
                    .frame(width: 42, height: 42)
                    .background(Color.purple.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                VStack(alignment: .leading, spacing: 4) {
                    Text("Paquete contador")
                        .font(.headline)
                    Text("ZIP mensual precontable")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text("No reemplaza al contador")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color.purple.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("business.accountantPack.moreTile")
    }
}

struct BusinessAccountantPackSurfaceView: View {
    let container: BusinessAppContainer
    @StateObject private var viewModel = BusinessAccountantPackViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                hero
                periodCard
                scopeCard
                downloadCard
                contentsCard
                limitsCard
            }
            .padding(18)
        }
        .navigationTitle("Paquete contador")
        .task { viewModel.configure(container: container) }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Cierre para contador", systemImage: "doc.zipper")
                .font(.title3.weight(.bold))
            Text("Descarga un ZIP mensual con datos operativos y precontables para revisión externa.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("Nexo no reemplaza al contador. Nexo arma un paquete precontable claro, trazable y auditable para que el contador revise más rápido.")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.quaternary)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private var periodCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Periodo")
                .font(.headline)
            HStack(spacing: 12) {
                Picker("Mes", selection: $viewModel.month) {
                    ForEach(1...12, id: \.self) { month in
                        Text(viewModel.monthTitle(month)).tag(month)
                    }
                }
                Picker("Año", selection: $viewModel.year) {
                    ForEach(viewModel.yearOptions, id: \.self) { year in
                        Text(String(year)).tag(year)
                    }
                }
            }
            .pickerStyle(.menu)
            Text("El ZIP se genera leyendo el cierre operativo mensual disponible en backend. No crea asientos ni declaraciones.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var scopeCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Alcance")
                .font(.headline)
            TextField("Sucursal", text: $viewModel.branchId)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)
            TextField("Actividad", text: $viewModel.activityId)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)
            Text("Para staging se prellenan branch/activity conocidos. Luego esto debe venir del selector real de sucursal/actividad.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var downloadCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Descarga")
                .font(.headline)
            if let errorMessage = viewModel.errorMessage {
                Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.orange.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            if let successMessage = viewModel.successMessage {
                Label(successMessage, systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.green)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.green.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            Button {
                Task { await viewModel.download() }
            } label: {
                HStack {
                    if viewModel.isDownloading {
                        ProgressView()
                    } else {
                        Image(systemName: "arrow.down.doc.fill")
                    }
                    Text(viewModel.isDownloading ? "Generando ZIP…" : "Descargar paquete ZIP")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isDownloading || !viewModel.canDownload)
            .accessibilityIdentifier("business.accountantPack.downloadButton")

            if let localFileURL = viewModel.localFileURL {
                ShareLink(item: localFileURL) {
                    Label("Compartir ZIP", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .accessibilityIdentifier("business.accountantPack.shareButton")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var contentsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Contenido esperado")
                .font(.headline)
            ForEach(viewModel.expectedFiles, id: \.self) { item in
                Label(item, systemImage: "checkmark.circle")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var limitsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Límites claros")
                .font(.headline)
            BusinessAccountantPackLimitRow(text: "No es contabilidad legal.")
            BusinessAccountantPackLimitRow(text: "No genera ATS ni declaraciones.")
            BusinessAccountantPackLimitRow(text: "No reemplaza revisión del contador.")
            BusinessAccountantPackLimitRow(text: "No envía automáticamente información a terceros.")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct BusinessAccountantPackLimitRow: View {
    let text: String

    var body: some View {
        Label(text, systemImage: "minus.circle")
            .font(.caption)
            .foregroundStyle(.secondary)
    }
}

@MainActor
final class BusinessAccountantPackViewModel: ObservableObject {
    @Published var year: Int
    @Published var month: Int
    @Published var branchId: String = "br_staging_matriz"
    @Published var activityId: String = "act_staging_restaurant"
    @Published private(set) var isDownloading = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var successMessage: String?
    @Published private(set) var localFileURL: URL?

    private var container: BusinessAppContainer?

    init(calendar: Calendar = .current) {
        let now = Date()
        year = calendar.component(.year, from: now)
        month = calendar.component(.month, from: now)
    }

    var yearOptions: [Int] {
        let current = Calendar.current.component(.year, from: Date())
        return Array((current - 2)...(current + 1)).reversed()
    }

    var canDownload: Bool {
        container != nil
        && (1...12).contains(month)
        && !branchId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && !activityId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    let expectedFiles = [
        "manifest.json",
        "resumen_precontable.json",
        "cierre_mensual.json",
        "cierres_diarios.json",
        "alertas.json",
        "ventas.csv",
        "pagos.csv",
        "caja.csv",
        "documentos_electronicos.csv",
        "cuentas_por_cobrar.csv",
        "README_CONTADOR.md",
    ]

    func configure(container: BusinessAppContainer) {
        self.container = container
    }

    func monthTitle(_ value: Int) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "es_EC")
        return formatter.monthSymbols[max(0, min(11, value - 1))].capitalized
    }

    func download() async {
        guard let container else {
            errorMessage = "No se pudo preparar el cliente de descarga."
            return
        }

        isDownloading = true
        errorMessage = nil
        successMessage = nil

        do {
            let fileURL = try await downloadPack(container: container)
            localFileURL = fileURL
            successMessage = "ZIP descargado: \(fileURL.lastPathComponent)"
        } catch {
            errorMessage = "No se pudo descargar el ZIP: \(error.localizedDescription)"
        }

        isDownloading = false
    }


    private func resolveAccessToken(container: BusinessAppContainer) throws -> String {
        _ = container
        throw BusinessAccountantPackDownloadError.message("Descarga ZIP backend validada; pendiente conectar método real de AuthTokenStoring para descarga desde Business.")
    }

    private func downloadPack(container: BusinessAppContainer) async throws -> URL {
        let trimmedBranchId = branchId.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedActivityId = activityId.trimmingCharacters(in: .whitespacesAndNewlines)

        let accessToken = try resolveAccessToken(container: container)

        guard var components = URLComponents(string: "http://localhost:8080") else {
            throw BusinessAccountantPackDownloadError.message("Base URL local inválida.")
        }

        components.path = "/api/v1/business/finance/accountant-pack/draft.zip"
        components.queryItems = [
            URLQueryItem(name: "year", value: String(year)),
            URLQueryItem(name: "month", value: String(format: "%02d", month)),
            URLQueryItem(name: "branchId", value: trimmedBranchId),
            URLQueryItem(name: "activityId", value: trimmedActivityId),
        ]

        guard let url = components.url else {
            throw BusinessAccountantPackDownloadError.message("URL de descarga inválida.")
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/zip", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue(trimmedBranchId, forHTTPHeaderField: "X-Branch-Id")
        request.setValue(UUID().uuidString.lowercased(), forHTTPHeaderField: "X-Correlation-Id")
        request.setValue("NexoBusinessIOS", forHTTPHeaderField: "X-Client-App")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw BusinessAccountantPackDownloadError.message("Respuesta HTTP inválida.")
        }
        guard (200...299).contains(httpResponse.statusCode) else {
            throw BusinessAccountantPackDownloadError.message("Backend respondió HTTP \(httpResponse.statusCode).")
        }
        guard !data.isEmpty else {
            throw BusinessAccountantPackDownloadError.message("El ZIP llegó vacío.")
        }

        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileName = "nexo_accountant_pack_\(year)_\(String(format: "%02d", month)).zip"
        let fileURL = directory.appendingPathComponent(fileName)
        try data.write(to: fileURL, options: Data.WritingOptions.atomic)
        return fileURL
    }
}

private enum BusinessAccountantPackDownloadError: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case let .message(value): return value
        }
    }
}
